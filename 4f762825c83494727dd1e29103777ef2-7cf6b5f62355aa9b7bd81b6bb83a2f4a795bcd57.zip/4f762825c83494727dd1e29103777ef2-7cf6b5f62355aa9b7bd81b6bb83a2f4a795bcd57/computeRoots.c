#include<stdio.h>
#include<stdlib.h>

#include "roots.h"

int main(int argc, char **argv) {

  if(argc != 4) {
    printf("Error: expected 3 coefficients\n");
    exit(1);
  }

  double a = atof(argv[1]);
  double b = atof(argv[2]);
  double c = atof(argv[3]);

  double root1 = getRoot01(a, b, c); //(-b + sqrt(b*b - 4*a*c)) / (2*a);
  double root2 = getRoot02(a, b, c); //(-b - sqrt(b*b - 4*a*c)) / (2*a);

  getRoots(a, b, c, &root1, &root2);

  printf("Roots of %f x^2 + %f x + %f are %f and %f\n", a, b, c, root1, root2);

  return 0;
}
