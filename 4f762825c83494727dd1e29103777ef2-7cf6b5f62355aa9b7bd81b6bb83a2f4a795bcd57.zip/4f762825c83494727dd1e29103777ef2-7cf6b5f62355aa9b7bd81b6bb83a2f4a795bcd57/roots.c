
#include<stdlib.h>
#include<math.h>

#include "roots.h"

//is this right?
void getRoots(double a, double b, double c, double *root1, double *root2) {
  *root1 = (-b + radical(a, b, c)) / (2*a);
  *root2 = (-b - radical(a, b, c)) / (2*a);
}

double radical(double a, double b, double c) {
  return sqrt(b*b - 4*a*c);
}

double getRoot01(double a, double b, double c) {
  return (-b + radical(a, b, c)) / (2*a);
}

double getRoot02(double a, double b, double c) {
  return (-b - radical(a, b, c)) / (2*a);
}


