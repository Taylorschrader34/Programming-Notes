
public class ComplexRootException extends RuntimeException {

	public ComplexRootException(String message) {
		super(message);
	}
	
}
